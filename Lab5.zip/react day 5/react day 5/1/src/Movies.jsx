import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { moviesPropagation, setCurrentPageadd, setCurrentPageaddmin } from './MoviesSlice3';

export default function Movies() {
  const dispatch = useDispatch();
  const { movies3, currentPage } = useSelector((state) => state.movies3);

  useEffect(() => {
    dispatch(moviesPropagation(currentPage));
  }, [dispatch, currentPage]);

  return (
    <div className='container'>
      <div className='row'>
        {movies3.map((movie) => (
          <div className='col-md-3' key={movie.id}>
            <div className='card mb-3'>
              <img src={'https://image.tmdb.org/t/p/w500' + movie.poster_path} className='card-img-top' alt={movie.original_title} />
              <div className='card-body'>
                <h5 className='card-title'>{movie.original_title}</h5>
                <p className='card-text'>{movie.overview.split(' ').slice(0, 10).join(' ')}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
      <div className='d-flex justify-content-center'>
        <button
          className='btn btn-success me-3'
          disabled={currentPage === 1}
          onClick={() => dispatch(setCurrentPageaddmin())}
        >
          Previous
        </button>
        <button className='btn btn-dark' onClick={() => dispatch(setCurrentPageadd())}>
          Next
        </button>
      </div>
    </div>
  );
}
