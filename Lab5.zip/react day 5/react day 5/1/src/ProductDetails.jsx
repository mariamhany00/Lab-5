import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getMoviesId } from './MoviesSlice2';
import { useParams } from 'react-router-dom';

export default function ProductDetails() {
  const { id } = useParams();
  const dispatch = useDispatch();
  const { movies2 } = useSelector((state) => state.movies2);

  useEffect(() => {
    dispatch(getMoviesId(id));
  }, [dispatch, id]);

  return (
    <div className='row'>
      <div className='col-md-3'>
        <div className='movie mt-3'>
          {movies2 && (
            <>
              <img src={'https://image.tmdb.org/t/p/w500' + movies2.poster_path} className='w-100' alt={movies2.original_title} />
              <h3>{movies2.original_title}</h3>
              <p>{movies2.overview?.split(" ").slice(0, 10).join(" ")}</p>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

