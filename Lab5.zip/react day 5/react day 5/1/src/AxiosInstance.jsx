import axios from "axios"


 const axiosInstance= axios.create({
    baseURL: "https://api.themoviedb.org/3/movie",
    params: {
        api_key: "93eef80a770c6ca7d6a6fb918f6195aa"
    }
})

export default axiosInstance;