import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';

export default function Navbar() {
  const location = useLocation();
  const [activeLink, setActiveLink] = useState('');

 
  useEffect(() => {
    setActiveLink(location.pathname);
  }, [location]);

  const routes = [
    {
      title: 'Login',
      href: '/login',
    },
    {
      title: 'Home',
      href: '/home',
    },
    {
      title: 'Address',
      href: '/address',
    },
    {
      title: 'Products',
      href: '/products',
    },
    {
      title: 'Movies',
      href: '/movies',
    },
  ];

  return (
    <nav className="navbar navbar-expand-lg navbar-light" style={{ backgroundColor: 'green', borderBottom: '1px solid white' }}>
      <div className="container-fluid">
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse justify-content-center" id="navbarSupportedContent">
          <ul className="navbar-nav me-auto my-2 my-lg-0 navbar-nav-scroll" style={{ "--bs-scroll-height": "100px" }}>
            {routes.map(route => (
              <li className="nav-item" key={route.href}>
                <Link
                  className={activeLink === route.href ? "nav-link active fw-bold mx-5" : "nav-link fw-bold mx-5"}
                  to={route.href}
                  style={{ color: 'white' }} 
                >
                  {route.title}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </nav>
  );
}

